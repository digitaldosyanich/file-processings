#!/bin/bash

set -uo pipefail

doWork() {
    dir="${1}"
    cd "${dir}" || return
    for file in *.mp3; do
       folder=$(basename "$file" ".mp3")
       mkdir -p "${folder}" && mv "${folder}".* "${folder}"
    done
}

doWork "$@"