#!/bin/bash

# Check if a folder path is provided as a command-line argument
if [ $# -ne 1 ]; then
    echo "Usage: $0 /path/to/folder"
    exit 1
fi

# Store the folder path provided as an argument
folder_path="$1"

# Verify that the provided path exists and is a directory
if [ ! -d "$folder_path" ]; then
    echo "Error: '$folder_path' is not a valid directory."
    exit 1
fi

# Ask for confirmation to delete all files
read -p "Are you sure you want to delete all files inside '$folder_path'? (y/n): " confirmation_files

if [ "$confirmation_files" != "y" ]; then
    echo "Operation canceled."
    exit 1
fi

# Delete all files inside subfolders of the specified folder
find "$folder_path" -mindepth 2 -type f -exec rm -f {} \;

echo "All files inside subfolders of '$folder_path' have been deleted."

# Ask for confirmation to delete all subfolders
read -p "Do you want to delete all subfolders inside '$folder_path'? (y/n): " confirmation_subfolders

if [ "$confirmation_subfolders" == "y" ]; then
    # Delete all subfolders of the specified folder
    find "$folder_path" -mindepth 2 -type d -exec rm -rf {} \;
    echo "All subfolders inside '$folder_path' have been deleted."
fi
